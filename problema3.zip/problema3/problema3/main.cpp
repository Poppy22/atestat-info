#include <iostream>
#include <fstream>
#include <string.h>

using namespace std;

int main()
{   int i;
    char s[20], s1[20];
    ifstream f("date.in");
    f>>s;
    f.close();
    strcpy(s1, s);
    ofstream g("date.out");
    g<<"Catena complementara de ADN: ";
    for(i=0; i<strlen(s1); i++)
        if(s1[i]=='A') s1[i]='T';
        else if (s1[i]=='T') s1[i]='A';
             else if (s1[i]=='C') s1[i]='G';
                  else s1[i]='C';
    g<<s1<<endl;
    g<<"Catena complementara de ARN: ";
    for(i=0; i<strlen(s); i++)
        if(s[i]=='A') s[i]='U';
        else if (s[i]=='T') s[i]='A';
             else if (s[i]=='C') s[i]='G';
                  else s[i]='C';
    g<<s;
    g.close();



}

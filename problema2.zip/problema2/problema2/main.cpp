#include <iostream>
#include <fstream>
#include <string.h>

using namespace std;

struct nucleotida
{ int numar;
  char tip;
} v[10];


int main()
{ int i, nr_total=0;
  ifstream f("date.in");
  for (i=0; i<2; i++)
    f>>v[i].numar>>v[i].tip;
  f.close();
  for(i=0; i<2; i++)
  { if (v[i].tip=='A' || v[i].tip=='T') nr_total=nr_total+v[i].numar*2;
    if (v[i].tip=='G' || v[i].tip=='G') nr_total=nr_total+v[i].numar*3;
  }
  ofstream g("date.out");
  g<<"Numarul legaturilor de hidrogen: "<<nr_total;
  g.close();

  return 0;
}

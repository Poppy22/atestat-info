#include <iostream>
#include <fstream>
#include <string.h>
using namespace std;

struct nucleotida
{ int numar;
  char tip;
} v[10];

int main()
{ int i;
  ifstream f("date.in");
  for(i=0; i<4; i++)
   {f>>v[i].numar;
    f>>v[i].tip;
   }
   f.close();
   for(i=0; i<4; i++)
    if(v[i].tip=='A') v[i].tip='T';
    else if(v[i].tip=='T') v[i].tip='A';
          else if (v[i].tip=='C') v[i].tip='G';
               else v[i].tip='C';
    ofstream g("date.out");
    g<<"Catena complementara:"<<endl;
    for(i=0; i<4; i++)
        g<<v[i].numar<<" nucleotide "<<v[i].tip<<endl;
    g.close();
    return 0;
}
